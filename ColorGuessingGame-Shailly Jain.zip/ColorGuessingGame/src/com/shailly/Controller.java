package com.shailly;

import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import java.util.Random;

public class Controller {


    private Color[] colors;
    private Rectangle[] rectangles;
    private Rectangle pickedRectangle;
    private Color pickedColor;

    @FXML
    public Rectangle one, two, three, four, five, six;

    @FXML
    public Label target;

    @FXML
    public VBox box;

    @FXML
    public void initialize(){
        rectangles = new Rectangle[6];
        colors = new Color[6];
        rectangles[0] = one;
        rectangles[1] = two;
        rectangles[2] = three;
        rectangles[3] = four;
        rectangles[4] = five;
        rectangles[5] = six;

        // set the game screen
        setGameScreen();
    }

    @FXML
    public void handleMouseClicked(MouseEvent mouseEvent){
        Rectangle rectangle = (Rectangle) mouseEvent.getSource();
        if( !rectangle.equals(pickedRectangle)){
            // selected rectangle is not given target
            FadeTransition fadeTransition = new FadeTransition(Duration.millis(1000), rectangle);
            fadeTransition.setFromValue(1.0);
            fadeTransition.setToValue(0.0);
            fadeTransition.play();
        } else{
            // selected correct rectangle

            // set the color of all of the rectangles to be the correct color
            for(int i = 0 ; i <6; ++i){
                rectangles[i].setFill(pickedColor);
            }
            setOpacityOfRectangles();
            FadeTransition fadeTransition = new FadeTransition(Duration.millis(1000), box);
            fadeTransition.setFromValue(0.0);
            fadeTransition.setToValue(1.0);
            fadeTransition.play();

            // start the game again
            setGameScreen();
        }

    }

    @FXML
    public void handleQuitButton(){
        Platform.exit();
    }

    @FXML
    public void handleResetButton(){
        setGameScreen();
    }



    private void setColors(){
        for(int i = 0 ; i < 6 ; ++i){
            colors[i] = generateRandomColor();
        }
    }

    private void setRectanglesColor(){
        for(int i = 0 ; i < 6; ++i){
            rectangles[i].setFill(colors[i]);
        }
    }

    private void setTargetColor(){
        Random random = new Random();
        int selectedIndex = random.nextInt(6);
        pickedRectangle = rectangles[selectedIndex];
        pickedColor = colors[selectedIndex];
        Color selectedColor = colors[selectedIndex];
        int red = (int)Math.round(selectedColor.getRed()*255);
        int green = (int)Math.round(selectedColor.getGreen()*255);
        int blue = (int)Math.round(selectedColor.getBlue()*255);
        String text = "RGB( " + red + ", " + blue + ", " + green + " )";
        target.setText(text);
    }

    private Color generateRandomColor(){
        Random random = new Random();
        // generate r, g and b in the range 0-1
        double r = (random.nextInt(255)/(double)255);
        double g = (random.nextInt(255)/(double)255);
        double b = (random.nextInt(255)/(double)255);
        return (new Color(r,g,b,1.0));
    }

    private void setOpacityOfRectangles(){
        for(int i = 0 ; i < 6; ++i){
            rectangles[i].setOpacity(1.0);
        }
    }

    private void setGameScreen(){

        // generate siz new colors
        setColors();
        // set rectangles color
        setRectanglesColor();
        // choose any rectangle's color and set it as target
        setTargetColor();
        // set opacity of every rectangle to 1.0
        setOpacityOfRectangles();

        FadeTransition fadeTransition = new FadeTransition(Duration.millis(2000), box);
        fadeTransition.setFromValue(0.0);
        fadeTransition.setToValue(1.0);
        fadeTransition.play();
    }

}
